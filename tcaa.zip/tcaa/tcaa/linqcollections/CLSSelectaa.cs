﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;
namespace pro.linqcollections { 
//example for  linq using 'select' clause
    class CLSSelectaa
    {
        public static void Main()
        {
            List<CLSERaa> erLst = new List<CLSERaa>()
            {
                new CLSERaa {rno=1001,sname="x5",m1=56.5,m2=63 },
                new CLSERaa {rno=1002,sname="x3",m1=98,m2=20 },
                new CLSERaa {rno=1003,sname="x1",m1=45.5,m2=52 }
            };
            var ds = from row in erLst
                     select row;
            foreach(var row in ds)
            {
                Console.Write("\n{0,4}\t{0,4}\t{1,4}", row.rno, row.sname);
                Console.Write("\t{0,5}\t{1,5}", row.m1, row.m2);
                Console.Write("\t{0,6}\t{1,5}\t{2,4}", row.total, row.average,row.result);

            }
        }
    }
}
/*
 
1001    1001      x5     56.5      63    119.5  59.75   pass
1002    1002      x3       98      20      118     59   fail
1003    1003      x1     45.5      52     97.5  48.75   pass
*/