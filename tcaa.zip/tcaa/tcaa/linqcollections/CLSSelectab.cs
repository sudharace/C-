﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pro.linqcollections
{
    class CLSSelectab
    {
        public static void Main()
        {
            List<CLSERaa> erLst = new List<CLSERaa>()
            {
                new CLSERaa {rno=1001,sname="x5",m1=56.5,m2=63 },
                new CLSERaa {rno=1002,sname="x3",m1=98,m2=20 },
                new CLSERaa {rno=1003,sname="x1",m1=45.5,m2=52 }
            };
            var ds = from row in erLst
                     select new { row.rno, row.result };
            foreach (var row in ds)
            {
                Console.WriteLine("\n{0,4}\t{1,4}",row.rno,row.result);
            }

        }
    }
    }
/*
 
1001    pass

1002    fail

1003    pass
*/