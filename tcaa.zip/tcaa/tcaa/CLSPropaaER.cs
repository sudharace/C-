﻿using System;
/*
 Example for develop property feature
 */


namespace pro
{
    class CLSPropaaER
    {
        private int _rno;
        private String _sname;
        private double _m1 = 0, _m2 = 0;
        public int Rno

        {
            get
            {
                return _rno;
            }
            set
            {
                _rno = value;
            }
        }
        public String Sname
        {
            get
            {
                return _sname;
            }
            set
            {
                _sname = value;
            }
        }
        public double m1
        {
            get
            {
                return _m1;
            }
            set
            {
                _m1 = value;
            }
        }
        public double m2
        {
            get
            {
                return _m2;
            }
            set
            {
                _m2 = value;
            }
        }
        public double Total

        {
            get
            {
                return _m1 + _m2;
            }

        }
        public double avg
        {
            get
            {
                return Total / 2;

            }
        }
        public String Result
        {
            get
            {
                return _m1 > 34.4 && _m2 > 34.4 ? "pass" : "fail";
            }
        }
    }
    class CLSPropaa
    {
        public static void Main()
        {
            CLSPropaaER er = new CLSPropaaER();
            er.Rno = 1001;
            er.Sname = "xx";
            er.m1 = 56.5;
            er.m2 = 63;
            Console.WriteLine(er.Rno);
            Console.WriteLine(er.Sname);
            Console.WriteLine(er.m1);
            Console.WriteLine(er.m2);
            Console.WriteLine(er.Total);
            Console.WriteLine(er.avg);
            Console.WriteLine(er.Result);
        }
    }

    }
/*
 *1001
xx
56.5
63
119.5
59.75
pass
*/
