﻿using System;

namespace pro
{
    class CLSCBVCBRaa
    {
        public static void uswap(int i, int j)
        {
            i = 5; j = 2;
            i = i + j;
            j = i - j;
            i = i - j;
            Console.WriteLine("swap[i]:" + i);
            Console.WriteLine("swap[j]:" + j);
        }
        public static void uExchange(ref int i, ref int j)

        {
            i = i + j + j;
            j = i - j + j;
            i = i - j - j;

            Console.WriteLine("exchange[i]:" + i);
            Console.WriteLine("exchange[j]:" + j);
        }
        public static void Main()
        {
            int a = 5, b = 2;
            int x = 4, y = 9;

            Console.WriteLine("before Swap[a]:" + a);
            Console.WriteLine("before Swap[b]:" + b);
                    uswap(a, b);
            Console.WriteLine("after exchange[a]:" + a);
            Console.WriteLine("after exchange[b]:" + b);

            Console.WriteLine("before exchange[x]:" + x);
            Console.WriteLine("before exchange[y]:" + y);

            uExchange(ref x, ref y);
                Console.WriteLine("after exchange[x]:" + x);
            Console.WriteLine("after exchange[y]:" + y);
        }




        }
    }
/*
 before Swap[a]:5
before Swap[b]:2
swap[i]:2
swap[j]:5
after exchange[a]:5
after exchange[b]:2
before exchange[x]:4
before exchange[y]:9
exchange[i]:-22
exchange[j]:22
after exchange[x]:-22
after exchange[y]:22
*/

