﻿using System;
/* example for user definded data type (enum)
 */ 
namespace pro
{
    class ENUMab
    {
        enum CCname
        {
            agriculture, domestic, commercial
        }
        public static void Main()
        {

            Console.WriteLine(typeof(CCname));


            Console.WriteLine(Enum.IsDefined(typeof(CCname), 0));
            Console.WriteLine(Enum.IsDefined(typeof(CCname), 1));
            Console.WriteLine(Enum.IsDefined(typeof(CCname), 2));
            Console.WriteLine(Enum.IsDefined(typeof(CCname), 3));
        }
    }
}
/*
pro.ENUMab+CCname
True
True
True
False
*/
