﻿using System;
/* example for type casting
 */ 
namespace pro
{
    class TCad
    {
        public static void Main()
        {
            int i = 5;
            double x = 6.9;
            int j = (int)x;
            double y = i;

            Console.WriteLine(i);//5
            Console.WriteLine(i);//6.9

            Console.WriteLine(i);//6
            Console.WriteLine(i);//5
        }

        }
}
/*
 5
5
5
5
Press any key to continue . . .


*/