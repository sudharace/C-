﻿using System;
using System.Data;
using System.Data.SqlClient;
namespace pro.uadonet
{
    class CLSSSelaa
    {
        public static void Main()
        {
            SqlConnection sqlcnn = null;
            SqlCommand sqlcmd = null;
            SqlDataAdapter sqlda = null;
            DataSet ds = null;
            DataTable dt = null;

            string qrysel = null;
            try
            {
                qrysel = "select*from eatbl";
                Console.WriteLine("\nEmployee salary allowance table columns name");

                sqlcnn = new SqlConnection(CLSSScnstr.cnstr);
                sqlcnn.Open();

                sqlcmd = new SqlCommand(qrysel, sqlcnn);
                sqlda = new SqlDataAdapter(sqlcmd);

                ds = new DataSet();
                sqlda.Fill(ds, "eatbl");
                dt = ds.Tables["eatbl"];

                Console.WriteLine("No. of columns: " + dt.Columns.Count);
                Console.WriteLine("No. of rows: " + dt.Rows.Count);
            }

            catch (Exception e)
            {
                Console.WriteLine("err.: " + e.Message);

            }
            finally
            {
                sqlcnn.Close();
            }
        }
    }
}
/*
 
Employee salary allowance table columns name
No. of columns: 8
No. of rows: 5
*/