﻿using System;
using System.Data.SqlClient;

namespace pro.uadonet
{
    class CLSSSInsaa
    {
        public static void Main()
        {
            SqlConnection sqlcnn = null;
            SqlCommand sqlcmd = null;

            String qryIns = null, ename = null, esal = null;


            try
            {
                qryIns = "insert into eatbl";
                qryIns += " (ename,esal) values";
                qryIns += " (@ename,@esal);";

                Console.WriteLine("\nEmployee salary Allowances for make a row");
                Console.Write("\nName:");
                ename = Console.ReadLine();

                Console.Write("\nsalary:");
                esal = Console.ReadLine();

                sqlcnn = new SqlConnection(CLSSScnstr.cnstr);
                sqlcnn.Open();

                sqlcmd = new SqlCommand(qryIns, sqlcnn);
                sqlcmd.Parameters.AddWithValue("@ename", ename);
                sqlcmd.Parameters.AddWithValue("@esal", esal);

                int afrs = sqlcmd.ExecuteNonQuery();

                if (afrs > 0)
                {
                    Console.WriteLine("\nAffected 1 row");
                }
                else
                {
                    Console.WriteLine("nAffected o row");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Err.:" + e.Message);
            }
            finally
            {
                sqlcnn.Close();

            }
        }
    }
}
/*
 
Employee salary Allowances for make a row

Name:dd

salary:909090909

Affected 1 row
P
*/