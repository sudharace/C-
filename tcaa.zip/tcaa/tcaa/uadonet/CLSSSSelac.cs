﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace pro.uadonet
{
    class CLSSSSelac
    {
        public static void Main()
        {
            SqlConnection sqlcnn = null;
            SqlCommand sqlcmd = null;
            SqlDataAdapter sqlda = null;
            DataSet ds = null;
            DataTable dt = null;

            string qrysel = null;
            try
            {
                qrysel = "select*from eatbl";
                Console.WriteLine("\nEmployee salary allowance table columns name");

                sqlcnn = new SqlConnection(CLSSScnstr.cnstr);
                sqlcnn.Open();

                sqlcmd = new SqlCommand(qrysel, sqlcnn);
                sqlda = new SqlDataAdapter(sqlcmd);

                ds = new DataSet();
                sqlda.Fill(ds, "eatbl");
                dt = ds.Tables["eatbl"];

                Console.WriteLine("\n1st row (index: 0), 7 columns value ");
                Console.Write(dt.Rows[0][0] + "\t");
                Console.Write(dt.Rows[0][1] + "\t");
                Console.Write(dt.Rows[0][2] + "\t");
                Console.Write(dt.Rows[0][3] + "\t");
                Console.Write(dt.Rows[0][4] + "\t");
                Console.Write(dt.Rows[0][5] + "\t");
                Console.Write(dt.Rows[0][6] + "\t");
                Console.Write(dt.Rows[0][7]);

                Console.WriteLine("\n4st row (index: 3), 7 columns value ");

                Console.Write(dt.Rows[0][0] + "\t");
                Console.Write(dt.Rows[3][1] + "\t");
                Console.Write(dt.Rows[3][2] + "\t");
                Console.Write(dt.Rows[3][3] + "\t");
                Console.Write(dt.Rows[3][4] + "\t");
                Console.Write(dt.Rows[3][5] + "\t");
                Console.Write(dt.Rows[3][6] + "\t");
                Console.Write(dt.Rows[3][7]);
            }

            catch (Exception e)
            {
                Console.WriteLine("err.: " + e.Message);
            }
            finally
            {
                sqlcnn.Close();
            }
        }
    }
}
/*
 *Employee salary allowance table columns name

1st row (index: 0), 7 columns value
1005    x1      800000.00       120000.00       160000.00       280000.00       1080000.00      800000.00
4st row (index: 3), 7 columns value
1005    x5      700000.00       105000.00       140000.00       245000.00       945000.00       700000.00
*/
