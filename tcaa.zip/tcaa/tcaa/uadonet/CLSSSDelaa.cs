﻿using System;
using System.Data.SqlClient;
namespace pro.uadonet
{
    class CLSSSDelaa
    {
        public static void Main()
        {
            SqlConnection sqlcnn = null;
            SqlCommand sqlcmd = null;
            string qryDel = null, eid = null;

            try
            {
                qryDel = "delete from eatbl";
                qryDel+= " where eid =@eid";
             

                Console.WriteLine("\nemployee salary allowance for erase a row");
                Console.Write("\nID:");
                eid = Console.ReadLine();

                sqlcnn = new SqlConnection(CLSSScnstr.cnstr);
                sqlcnn.Open();

                sqlcmd = new SqlCommand(qryDel,sqlcnn);
                sqlcmd.Parameters.AddWithValue("@eid", eid);

                int afrs = sqlcmd.ExecuteNonQuery();

                if (afrs > 0)
                {
                    Console.WriteLine("\nAffected 1 row");
                }
                else
                {
                    Console.WriteLine("nAffected o row");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Err.:" + e.Message);
            }
            finally
            {
                sqlcnn.Close();

            }
        }
    }
}
/*
 
employee salary allowance for erase a row

ID:1004

Affected 1 row
*/


