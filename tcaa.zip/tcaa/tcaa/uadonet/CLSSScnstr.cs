﻿using System;
using System.Data;
using System.Data.SqlClient;


namespace pro.uadonet
{
     public class CLSSScnstr
    {

        public static string cnstr = "" +
            "data source=.;" +
            "initial catalog=cmrdb;" +
            "integrated security=true;";

    }
}
