﻿using System;
/* example for exception handling
 */ 
namespace pro
{
    class EHaa
    {
        public static void Main()
        {
            try
            {
                Console.WriteLine("welcome");
                int i = 10, j = 0;
                Console.WriteLine(i / j);
            }
            catch (Exception e)
            {
                Console.WriteLine("err.:" + e.Message);

            }
            Console.WriteLine("visit again");
        }
    }
}
/*
 welcome
visit again


*/
