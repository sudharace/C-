﻿using System;
/* example for @ identifier
 @identifier develop string data type value
 */

namespace pro
{
    class CLSAtaa
    {
        public static void Main()
        {
            Console.WriteLine("ab\ncd");
            Console.WriteLine("ab\\ncd");
            Console.WriteLine(@"ab\ncd");
        }
    }
}
/*
 ab
cd
ab\ncd
ab\ncd
*/