﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using usc = System.Console;
// how to aasign alias name class for reduce program coding.
namespace pro.CLASS
{
    class CLSANaa
    {
        public static void Main()
        {
            usc.WriteLine("hi");
            usc.WriteLine(9 + 7);
        }
    }
}
/*
 hi
16
*/