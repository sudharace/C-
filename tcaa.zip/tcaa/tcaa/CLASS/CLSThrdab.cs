﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace pro.CLASS
{
    class CLSThrdab
    {
        public static void ushow()
        {
            for (int i=0; i<60; i+=10)
            {
                Console.WriteLine(Thread.CurrentThread.Name + "\t" + i);
                Thread.Sleep(200);
            }
        }
        public static void Main()
        {
            ThreadStart ts = new ThreadStart(ushow);
            Thread thrd = new Thread(ts);
            thrd.Name = "Task1";
            thrd.Start();
            for (int i=1; i<6;i++)
            {
                Console.WriteLine(Thread.CurrentThread.Name + "\t" + i);
                    Thread.Sleep(200);
            }
        }
    }
}
/*
 Task1   0
        1
        2
Task1   10
Task1   20
        3
        4
Task1   30
Task1   40
        5
Task1   50
*/