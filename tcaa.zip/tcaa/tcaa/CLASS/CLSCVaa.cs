﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// example for convariance
namespace pro.CLASS
{
    class CLSCVaa
    {
        public static void Main()
        {
            string[] sarr = { "aa", "22", "cc" };
            object[] obj = sarr;
            obj[1] = "bb";
            foreach (string s in sarr)
                Console.WriteLine(s);

        }
    }
}
/*
 aa
bb
cc
*/