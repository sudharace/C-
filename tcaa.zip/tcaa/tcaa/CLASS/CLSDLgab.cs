﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//how to refer instance and static method using delegate feature.
namespace pro.CLASS
{
    class CLSDLgab
    {
        delegate void ushow();
        public void uexhibit()
        {
            Console.WriteLine("method.uexhibit");
        }
        public static void uDisplay()
        {
            Console.WriteLine("method.uDisplay");
        }
        public static void Main()
        {
            ushow us = new CLSDLgab().uexhibit;
            us();
            us = uDisplay;
            us();
        }
    }
}
/*
 method.uexhibit
method.uDisplay
*/
