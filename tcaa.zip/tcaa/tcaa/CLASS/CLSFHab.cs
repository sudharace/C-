﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
// example for file handling ;how to append new content to exists file.
namespace pro.CLASS
{
    class CLSFHab
    {
        public static void Main()
        {
            byte[] bytarr = Encoding.UTF8.GetBytes("Cool drinks\n7up\ncoke\npepsi\n");
            FileStream fs = new FileStream("Drinks.txt",FileMode.Append);
            fs.Write(bytarr, 0, bytarr.Length);
            fs.Close();
            Console.WriteLine("succesfully update a file ");
        }
    }
}
/*
 succesfully update a file
*/