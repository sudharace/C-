﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
// example for  file handling.
namespace pro.CLASS
{
    class CLSFHaa
    {
        public static void Main()
        {
            byte[] bytarr = Encoding.UTF8.GetBytes("Hotdrinks\n coffee\ntea\nmilk\n");
                //3+1+6+[1]+6+[1]+3+[1]+4+[1]=>27
                FileStream fs= new FileStream("drinks.txt",FileMode.Create);
            fs.Write(bytarr, 0, bytarr.Length);
            fs. Close();
            Console.WriteLine("successfully created new file");
        }
    }
}
/*
successfully created new file
*/