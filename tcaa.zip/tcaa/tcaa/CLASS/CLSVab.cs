﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// example for covariance limitation
namespace pro.CLASS
{
    class CLSVab
    {
        public static void Main()
        {
            int[]sarr={ 9, 5, 7 };
            //object[]obj=ii
            //error cnnot impliccity convert by 
           
        }
    }
}
