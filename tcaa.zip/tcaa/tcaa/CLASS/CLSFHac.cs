﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
/* example for file handling . 'read and open' mode help for read file content from exit file

namespace pro.CLASS
{
    class CLSFHac
    {
        public static void Main()
        {
           FileStream fs = new FileStream ("Drinks.txt,Filemode.open");
            Console.WriteLine("Filesize (in bytes):\n");

            Console.WriteLine(fs.Length);
            byte[] bytarr = new byte[fs.Length];
            fs.Read(bytarr, 0, bytarr.Length);
            fs.Close();

            Console.WriteLine("File content:\n");
            Console.WriteLine(Encoding.UTF8.GetString(bytarr));
        }
    }
}
*/
