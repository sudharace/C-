﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//example for how to access datatype from CTS.
namespace pro.CLASS
{
    class CLSInt32aa
    {
        public static void Main()
        {
            Int32 i = 5;
            Console.WriteLine(i);
        }
    }
}
/*
  5
 */ 
 
