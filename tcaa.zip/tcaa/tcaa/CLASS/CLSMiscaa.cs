﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// example for decimal dtatype with (m) .

namespace pro.CLASS
{
    class CLSMiscaa
    {
        public static void Main()
        {
            decimal d = 5.9m;
            Console.WriteLine(d);
            Console.WriteLine("BOX\rf");
        }
    }
}
/*
 5.9
fOX
*/