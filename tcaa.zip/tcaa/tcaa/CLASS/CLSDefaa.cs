﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//example for default keyboard and netural value datatype.
namespace pro.CLASS
{
    class CLSDefaa
    {
        public static void Main()
        {
            Console.WriteLine(default(int));
                Console.WriteLine(default(float));
            Console.WriteLine(default(double));
            Console.WriteLine(default(char));
            Console.WriteLine(default(bool));

            Console.WriteLine(default(DateTime));
            Console.WriteLine(default(string));
        }
    }
}
/*
 0
0
0

False
01-01-0001 00:00:00
*/
