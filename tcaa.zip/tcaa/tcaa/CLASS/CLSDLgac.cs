﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//example for multi cast delgating.
namespace pro.CLASS
{
    class CLSDLgac
    {
        delegate void ucalc(int i, int j);
        public static void usum(int x, int y)
        {
            Console.WriteLine("{0}+{1}={2}", x, y, x + y);
        }
        public static void uminus(int x,int y)
        {
            Console.WriteLine("{0}-{1}={2}", x, y, x - y);
        }
        public static void Main()
        {
            ucalc uc = usum;
            uc += uminus;
            uc(5, 2);

            Console.WriteLine("\n");
            uc = usum + uc;
            uc(5, 4);
        }
    }
}
/*
 *5+2=7
5-2=3


5+4=9
5+4=9
5-4=1
*/
