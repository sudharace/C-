﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System .Threading;
//example for 'THREAD'
namespace pro.CLASS
{
    class CLSThrdaa
    {
        public static void ushow()
        {
            for(int i=10; i<60;i+=10)
            {
                Console.WriteLine(i);
                Thread.Sleep(200);
            }
        }
        public static void uDisplay()
        {
            for (int i = 1; i < 6; i++)
            {
            Console.WriteLine(i);//1,2,3,4,5.
                Thread.Sleep(200);//milliseconds=20
        }
    }
        public static void Main()
        {
            //ushow()denote method callig part
            //ushow denote method address

         //   Thread start tsa = new Thread start(ushow);
          //  Thread start tsb = new Thread start(uDisplay);

          //  Thread thrda = new Thread(tsa);
           // Thread thrdb = new Thread(tsb);

          //  thrda.Start();
           // thrdb.Start();
        }

    }
}
