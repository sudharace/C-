﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*example for memory management system
namespace pro.CLASS
{
    class CLMMa
    {
        public CLMMa()
        {
            Console.WriteLine("constructor :CLMMaa");
        }
        public static uSum(int x, int y)
        {
            Console.WriteLine(x + y);


        }
        CLMMa()
        {
            Console.WriteLine("destructor :CLMMaa");
        }

    
    }
}
class CLMMaa
{
    public static void Main()
    {
        CLMMaa obj = new CLMMaa();
        obj.uSum
    }
}
*/