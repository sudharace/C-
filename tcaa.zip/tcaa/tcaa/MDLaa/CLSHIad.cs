﻿using System;
namespace pro.accessspecifier
{
    class CLSHIaa
    {
        public CLSHIaa()
        {
            Console.WriteLine("constuctor : CLSHIaa");
        }
        ~CLSHIaa()

        {
            Console.WriteLine(" Destructor : CLSHIaa");

        }
    }
    class CLSHIab : CLSHIaa

    {
        public CLSHIab()

        {
            Console.WriteLine("constructor : CLSHIab");

        }
        ~CLSHIab()
        {
            Console.WriteLine("Destructor : CLSHIab");

        }
    }
    class CLSHIac : CLSHIab
    {
        public CLSHIac()
        {
            Console.WriteLine("constructor :CLSHIac");

        }
        ~CLSHIac()
        {
            Console.WriteLine("Destrcctor :CLSHIac");

        }
    }

    class CLSHIad
    {
        public static void Main()
        {
            new CLSHIac();

        }
    }
}
/*
 Constructor : CLSMLIaa
constructor : CLSMLIab
constructor : CLSMLIac

Destructor : CLSMLIac
 Destructor : CLSMLIab
Destructor : CLSMLaa

 */
