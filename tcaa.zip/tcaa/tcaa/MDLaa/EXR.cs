﻿using System;

namespace pro
{
    class EXR
    {
        public static void Main()
        {
            Console.WriteLine("enter  following inputs for exam Result exercise");
            string ip = null;
            Console.WriteLine("\n Roll number:\t");
            ip = Console.ReadLine();
            int rno = 0;


            int.TryParse(ip, out rno);
            Console.WriteLine("\n student name:\t");
            string sname = Console.ReadLine();
            Console.WriteLine("\n mark-1:\t");
            ip = Console.ReadLine();
            double m1 = 0;
            double.TryParse(ip, out m1);
            Console.WriteLine("\n mark-2:\t");
            double m2 = 0;
            double.TryParse(ip, out m2);
            double total = (m1 + m2), avg = (m1 + m2) / 2;
            bool result = (m1 > 34.4 && m2 > 34.4);
            Console.WriteLine("exam Result info :\n");

            Console.WriteLine("Rollno:\t" + rno);
            Console.WriteLine("name:\t" + sname);
            Console.WriteLine("mark-1:\t" + m1);
            Console.WriteLine("mark-2:\t" + m2);
            Console.WriteLine("total:\t" + total);
            Console.WriteLine("average:\t" + avg);
            Console.WriteLine("Result :\t" + (result ? "pass" : "fail"));

        }
    }
}
/*
enter following inputs for exam Result exercise

Roll number:
1001

 student name:
vino

 mark-1:
40

 mark-2:
exam Result info :

Rollno: 1001
name:   vino
mark-1: 40
mark-2: 40
total:  80
average:        40
Result :        pass
Press any key to continue . . .
    */
     











   
