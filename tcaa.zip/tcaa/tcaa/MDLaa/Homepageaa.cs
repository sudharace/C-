﻿using System;

namespace pro.MDLaa
{
    class CLSHomeaa
    {
        public static void Main()
        {
            Console.WriteLine("choose excute app:\n");
            Console.WriteLine("exam result:\n");
            Console.WriteLine("employee allowance:\n");
            Console.WriteLine("employee salary tax:\n");
            Console.WriteLine("electricity bill:\n");
            Console.WriteLine("enter app no.between 1to 4:");

            int i = 0;
            int.TryParse (Console.ReadLine(), out i);

            if (! (i >=1 &&i <= 4))
            {
                Console.WriteLine("invalid App no");
                return;
            }
            if (i == 1)
            {
                EXR.Main();
                return;
            }
            if (i == 2);
            {
                EMSA.Main();
                return;
            }
            if (i == 3) 
            {
                SAT.Main();
                return;
            }

            ELEBI.Main();
           
            

            }
            }
        }

    

