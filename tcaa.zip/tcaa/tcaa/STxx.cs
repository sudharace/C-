﻿using System;
/* example for employee salary tax
 */ 
namespace NSA
{
    class STxx
    {
        public static void Main()
        {
            Console.WriteLine("enter employee info");
            string ip = null;
            Console.Write("ID:\t");
            ip = Console.ReadLine();
            int eid = 0;
            int.TryParse(ip, out eid);
            Console.Write("name:\t");
            string ename = Console.ReadLine();
            Console.Write("salary:\t");
            ip = Console.ReadLine();
            double esal = 0;
            double.TryParse(ip, out esal);
            double tax10 = 0, tax20 = 0, tax30 = 0, taxtot = 0, npay = 0;

            if (esal > 1000000)

            {
                tax10 = 25000;
                tax20 = 1000000;
                tax30 = (esal - 10000000) * 30 / 100;

            }
            else if (esal > 500000)

            {
                tax10 = 25000;
                tax20 = (esal - 500000) * 20 / 100;
            }
            else if (esal > 250000)
            {
                tax10 = (esal - 2500000) * 10 / 100;


            } else if (esal < 0) ;

            esal = 0;

            {
                taxtot = tax10 + tax20 + tax30;
                npay = esal - taxtot;

                Console.WriteLine("employee salary tax info");

                Console.WriteLine("ID:\t" + eid);
                Console.WriteLine("Name:\t" + ename);
                Console.WriteLine("salary:\t" + esal);
                Console.WriteLine("Tax10%:\t" + tax10);
                Console.WriteLine("Tax20%;\t" + tax20);
                Console.WriteLine("Tax30%:\t" + tax30);
                Console.WriteLine("Totaltax:\t" + taxtot);
                Console.WriteLine("net pay:\t" + npay);
            }
        }
    }
}

/*
 enter employee info
ID:     1001
name:   guna
salary: 100000
employee salary tax info
ID:     1001
Name:   guna
salary: 0
Tax10%: 0
Tax20%; 0
Tax30%: 0
Totaltax:       0
net pay:        0
*/