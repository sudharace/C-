﻿using System;
/* example for user define type-casting feature with exception handling
 */ 
namespace pro
{
    class TCab
    {
        public static void Main()
        {

            string s = "fox";
            int i = 0;
            int.TryParse(s, out i);
            Console.WriteLine(i + "_" + i.GetType());
            Console.WriteLine(s + "_" + s.GetType());
        }
        }
}

/*
 0_System.Int32
fox_System.String
Press any key to continue . . .

*/
