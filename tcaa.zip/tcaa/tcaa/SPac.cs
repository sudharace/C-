﻿using System;
/* how to develop library feature
 */ 
namespace pro
{
    class SPac
    {
        public static void Main()
    
        {
            UDCLMath umath = new UDCLMath();
            Console.WriteLine(umath.udmsum(1,9));
            umath.udmMultiply(2, 8);
            Console.WriteLine(UDCLMath.udmMinus(6 ,2));
            UDCLMath.udmDivide(20, 3);

        }
    }
}
/*
 10
16
4
6
*/
