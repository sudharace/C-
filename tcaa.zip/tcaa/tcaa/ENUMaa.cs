﻿using System;
/* example for user-defined data type (enum)
 */ 

namespace pro
{
    class ENUMaa
    {
        enum CCname
        {

            agriculture, domestic, commercial
        }
        public static void Main()
        {
            CCname ccn;


            ccn = CCname.agriculture;
            Console.WriteLine(ccn + "_" + ccn.GetType());


            Console.WriteLine((int)CCname.agriculture);//0
            Console.WriteLine((int)CCname.domestic);//1
            Console.WriteLine((int)CCname.commercial);//2

            Console.WriteLine((CCname)0);//agriculture)
            Console.WriteLine((CCname)1);//domestic)
            Console.WriteLine((CCname)2);//commercial)
        }
    }
}
/*
 *agriculture_pro.ENUMaa+CCname
0
1
2
agriculture
domestic
commercial
Press any key to continue . . .

*/














        
    
