﻿using System;
/* method write line
 */ 


namespace pro
{
    class OSaa
    {
       public static void  Main(string []args)
        {
            Console.WriteLine(4 + 5 + 7);
        }
    }
}
/*
16

*/

