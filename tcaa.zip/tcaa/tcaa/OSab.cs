﻿using System;
/* write method
 */ 

namespace pro
{
    class OSab
    {
        public static void Main()
        {
            Console.WriteLine("welcome");
            Console.WriteLine("sun");
            Console.WriteLine("mon");
            Console.WriteLine("tue");
            Console.WriteLine("wed");
            Console.WriteLine("thu");
            Console.WriteLine("fri");
            Console.WriteLine("sat");

            Console.WriteLine("thanks");
        }

        }
}/*
welcome
sun
mon
tue
wed
thu
fri
sat
thanks
Press any key to continue . . .

*/





