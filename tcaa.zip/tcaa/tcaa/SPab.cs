﻿using System;
/* example for sub program (catagory : procedure)
 */ 


namespace pro
{
    class SPab
    {
        public void udsum(int x, int y)
        {
            Console.WriteLine(x + y);
        }
        public static void udMinus(int x, int y)
        {
            Console.WriteLine(x - y);

        }
        public static void Main()
        {
            SPab spb = new SPab();
            spb.udsum(1, 9);
            SPab.udMinus(6, 3);
        }
    }
}
/*
 10
3
Press any key to continue . . .

*/
