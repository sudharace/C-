﻿using System;
/* example for exception property name message
*/

namespace pro
{
    class Excep
    {
        public  static void Main()
        {
            string s = "5";
            int i = 0;
            try
            {

                i = int.Parse(s);
            }
            catch (Exception e)
            {

                i = 0;
                Console.WriteLine("err-1: " + e.Message);

            }

            Console.WriteLine(s + "_" + s.GetType());
            Console.WriteLine(i + "_" + i.GetType());
            s = "fox9";
            try

            {

                i = int.Parse(s);

            }
            catch (Exception e)
            {

                i = 0;
                Console.WriteLine("err-2:" + e.Message);
            }
            Console.WriteLine(s + "_" + s.GetType());
            Console.WriteLine(i + "_" + i.GetType());



        }



        }
}
/*
 5_System.String
5_System.Int32
err-2:Input string was not in a correct format.
fox9_System.String
0_System.Int32
Press any key to continue . . .

*/