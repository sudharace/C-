﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pro
{
    class CLSCnStr
    {
         
        public static string forcmrdb
        {
            get
            {
                return "data source=.; initial catalog=cmrdb;integrated security = true;";
            }
        }
    }
}