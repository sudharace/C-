﻿using System;
/*
    foreach mulitple arugment
 */
 
namespace pro
{
    class CLLSUM
    {
        public static void Main(string[]args)
        {
            if (args.Length==0)
            {
                Console.WriteLine("invalid arugement\n");
                return;
            }
            double i = 0, j = 0;
            foreach (string s in args)
            {
                i = 0;
                double.TryParse(s, out i);
                j += i;

            }
            Console.WriteLine(j);
        }
    }
}
/*
 invalid arugement
 */
