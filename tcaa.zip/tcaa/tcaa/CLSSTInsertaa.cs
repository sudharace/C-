﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Linq;
namespace pro
{
    class CLSSTInsertaa
    {
        public static  void Main()
        {
           CLSSTaa st = new CLSSTaa();
            st.ename = "x9";
            st.esal = 90000;
            DataContext dc = new DataContext(CLSCnStr.forcmrdb);
            dc.GetTable<CLSSTaa>().InsertOnSubmit(st);
            dc.SubmitChanges();
            Console.WriteLine("1row affected");
           
        }
    }
}
/*
 1row affected
*/