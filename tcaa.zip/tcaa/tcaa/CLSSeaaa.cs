﻿using System;

namespace pro
{
    class CLSSeaaa
    {
        public CLSSeaaa()
        {
            Console.WriteLine("constructor:CLSSeaaa");

        }
        ~CLSSeaaa()
        {
            Console.WriteLine("Destructor :CLSSeaaa");
        }
    }
    sealed class CLSSeaab : CLSSeaaa
    {
        public CLSSeaab()

        {
            Console.WriteLine("constructor:CLSSeaab");
        }
        ~CLSSeaab()
        {
            Console.WriteLine("Destructor:CLSSeaab");
        }
    }
            class CLSSealedaa
    {
        public static void Main()
        {
            new CLSSeaab();
            
        }
    }
        

        
    }

/*
 constructor:CLSSeaaa
constructor:CLSSeaab
Destructor:CLSSeaab
Destructor :CLSSeaaa
*/

