﻿using System;
/* example for sub program (catagory :procedure ,function)
 */

namespace pro
{
    class SPaa
    {
        public int udsum(int x, int y)
        {


            return x + y;
        }
        public static int udMinus(int x, int y)
        {
            return x - y;
        }
        public static void Main()
        {
            SPaa spa = new SPaa();
            Console.WriteLine(spa.udsum(4, 5));
            Console.WriteLine(SPaa.udMinus(8, 1));

        }
    }
}
   /*
    9
7
*/
