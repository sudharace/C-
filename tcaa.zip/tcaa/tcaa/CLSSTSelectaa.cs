﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using System.Data.Linq;

namespace pro
{
    class CLSSTSelectaa
    {
        public static void Main()
        {
          DataContext dc = new DataContext(CLSCnStr.forcmrdb);
            var ds = from row in dc.GetTable<CLSSTaa>()
                     select new
                     {
                         eid = row.eid,
                         ename = row.ename,
                         esal = row.esal,
                         tax10 = row.tax10,
                         tax20 = row.tax20,
                         tax30 = row.tax30,
                         ttax = row.ttax,
                         npay = row.npay
                     };
            Console.WriteLine("\n salary tax table has record \n");
            foreach (var obj in ds)
            {
                Console.Write("{0,4}\t", obj.eid);
                Console.Write("{0,-5}", obj.ename);
                Console.Write("{0,12}", obj.esal);
                Console.Write("{0,12}", obj.tax10);
                Console.Write("{0,12}", obj.tax20);
                Console.Write("{0,12}", obj.tax30);
                Console.Write("{0,12}", obj.ttax);
                Console.Write("{0,12}", obj.npay);

                Console.Write("\n");
            }

        }
    }
}
/*
 salary tax table has record

1004    x3      800000.00   25000.000  100000.000       0.000  125000.000  875000.000
1005    x4     1600000.00   25000.000  100000.000  180000.000  305000.000 1855000.000
1006    x2      900000.00   25000.000  100000.000       0.000  125000.000  975000.000
1007    x8      500000.00   25000.000       0.000       0.000   25000.000  475000.000
1009    x9       90000.00       0.000       0.000       0.000       0.000   90000.000
1010    x9       90000.00       0.000       0.000       0.000       0.000   90000.000
1011    x9       90000.00       0.000       0.000       0.000       0.000   90000.000
*/
