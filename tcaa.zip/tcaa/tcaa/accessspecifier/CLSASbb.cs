﻿using System;
/* example for aacces specifier : 'private','public'
 */ 

namespace pro.accessspecifier
{
    class CLSASba

    {
        private int x;

        public void setData(int i)

        {
            x = i;
        }
        public void showData()
        {
            Console.WriteLine("x :" + x);

        }

    }
    class CLSASbb
    {
        public static void Main()

        {
            CLSASba ba = new CLSASba();
            ba.setData(5);

            ba.showData();
        }
    }
}
/*
 x :5
 */



