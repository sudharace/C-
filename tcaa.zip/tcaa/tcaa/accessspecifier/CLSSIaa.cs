﻿using System;


/* single  inheritance with constuctor and destructor features
 
    */

namespace pro.accessspecifier
{
    class CLSSIaa
    {
        public CLSSIaa()
        {
            Console.WriteLine("constructor : CLSSIaa");
        }
        ~CLSSIaa()
        {
            Console.WriteLine("Destructor : CLSSIaa");


        }
    }
    class CLSSIab : CLSSIaa
    {
        public CLSSIab()
        {
            Console.WriteLine("Constructor : CLSSIaa");
        }
        ~CLSSIab()
        {
            Console.WriteLine("Destructor : CLSSIab");
        }
    }
    class CLSSIac
    {
        public static void Main()
        {
            new CLSSIab();
        }
    }
}
/*

constructor : CLSSIaa
Constructor : CLSSIaa

Destructor : CLSSIab
Destructor : CLSSIaa
*/


