﻿using System;
/* example for access specifier : 'private'
*/
namespace pro.accessspecifier
{
    class CLSASaa
    {
        private int x;
    }
    class CLSASab
    {

    
       public static  void Main()
        {
            CLSASaa aa = new  CLSASaa();

        }
    }
}
/*
 Press any key to continue . . .
 */
