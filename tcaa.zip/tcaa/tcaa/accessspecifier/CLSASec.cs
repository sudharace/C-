﻿using System;
/* example for access specifier :'public '
 */ 

namespace pro.accessspecifier
{
    class CLSASea

    {
        public int x;

    }
    class CLSAeb : CLSASea
    {
        public void showdata()
        {
            Console.WriteLine(x);

        }
        class CLSASec

        {
            public static void Main()
            {
                CLSAeb eb = new CLSAeb();
                eb.showdata();
                Console.WriteLine(eb.x);
            }
        }

    }
}
/*
  0
0
*/
