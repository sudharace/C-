﻿using System;
/* example for access specifier : 'protected'
 */ 

namespace pro.accessspecifier
{
    class CLSAda
    {
        protected int x;

    }
    class CLSAdb : CLSAda
    {
        public void showData()
        {
            Console.WriteLine(x);//0
        }
    }
    class CLSASdc
    {
        public static void Main()
        {

            CLSASdb db = new CLSASdb();

            db.showdata();

            // Console.writeline(db.x);
        }


    }
}
/*
 0
 */


