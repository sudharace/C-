﻿using System;
/* example for  for protected acces specifier (or modifier)
 */ 

namespace pro.accessspecifier
{
    class CLASAda
    {
        protected int x;
    }
    class CLSASdb : CLASAda
    {
        public void showdata()
        {
            Console.WriteLine(x);

        }
    }
    class CLASAdc
    {
        public static void Main()
        {
            CLSASdb db = new CLSASdb();
            db.showdata();
        }
    }

}
/*
  0
  */
    

    

    

