﻿using System;
/* 
 example for  multilevel  inheritance  with  constructor and desstructor

*/
namespace pro.accessspecifier
{
    class CLSMLIaa
    {
        public CLSMLIaa()
        {
            Console.WriteLine("Constructor : CLSMLIaa");
        }
        ~CLSMLIaa()
        {
            Console.WriteLine("Destructor : CLSMLaa");

        }

        }
    class CLSMLIab : CLSMLIaa
    
    {
        public CLSMLIab()
        {
            Console.WriteLine("constructor : CLSMLIab");
        }


        ~CLSMLIab()
        {
            Console.WriteLine(" Destructor : CLSMLIab");
        }

            }
    class CLSMLIac: CLSMLIab
    {
        public CLSMLIac()
        {
            Console.WriteLine("constructor : CLSMLIac");
        }
        ~CLSMLIac()
        {
            Console.WriteLine("Destructor : CLSMLIac");
        }
    }
    class CLSMLIad
                {
        public static void Main()
        {
            new CLSMLIac();
        }


            }
        }

/*
 Constructor : CLSMLIaa
constructor : CLSMLIab
constructor : CLSMLIac

Destructor : CLSMLIac
 Destructor : CLSMLIab
Destructor : CLSMLaa
*/

