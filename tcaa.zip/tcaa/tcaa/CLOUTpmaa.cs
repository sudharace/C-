﻿using System;// example for outparameter
namespace pro
{
    
    class CLOUTpmaa
    {
        public static void uSum (int i,int j,out int k)
        {
            k = i + j;
        }
        public static void uFLNames(String fullname, out String fname, out String Lname)
        {
            int bsi = fullname.LastIndexOf(" ");
            if (bsi==-1)
            {
                fname = fullname;
                Lname = null;
                return;

            }
            fname = fullname.Substring(0, bsi).Trim();
            Lname = fullname.Substring(bsi).Trim();
        }
            
            

            public static void Main()
        {
            int x = 0;
            uSum(2, 5, out x);
            Console.WriteLine(x);
            String fullname="raja raghu raman", sonname = null, fathername = null;
            uFLNames(fullname, out sonname, out fathername); 
            Console.WriteLine(sonname);
            Console.WriteLine(fathername);

            Console.WriteLine("abcdABCDefghABCD".IndexOf("A"));//4


            Console.WriteLine("abcdABCDefghABCD".LastIndexOf("A"));//2


            Console.WriteLine("abcdABCDefghABCD".Substring(0,8));//abcdABCD


            Console.WriteLine("abcdABCDefghABCD".Substring(10));//ghABCD

        }
        }
    }
/*
 7
raja raghu
raman
4
12
abcdABCD
ghABCD
*/

