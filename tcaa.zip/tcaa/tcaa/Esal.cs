﻿using System;
/* example for  employee salary 
 */ 

namespace pro
{
    class Esal
    {
        public static void Main()
        {
            Console.WriteLine("enter employee info");
            string ip = null;

            Console.Write("ID :\t");
            ip = Console.ReadLine();

            int eid = 0;
            int.TryParse(ip, out eid);

            Console.Write("Name:\t");
            string ename = Console.ReadLine();

            Console.Write("salary:\t");
            ip = Console.ReadLine();

            double esal = 0;
            double.TryParse(ip, out esal);

            double hra = esal  * (20.0 / 100);
            double da = esal  * (15.0 / 100);
            double pf = esal * (35.0 / 100);

            double gpay = esal + hra + da;
            double npay = gpay - pf;

            Console.WriteLine("ID:/t" + eid);
            Console.WriteLine("name:/t" + ename );
            Console.WriteLine("salary:/t" + esal);
            Console.WriteLine("hra:/t" + hra);
            Console.WriteLine("pf:/t" + pf);
            Console.WriteLine("gpay:/t" + gpay);
            Console.WriteLine("npay:/t" + npay);
            





        }

    }
    
}
/*
 
enter employee info
ID :    1001
Name:   VINO
salary: 100000
ID:/t1001
name:/tVINO
salary:/t100000
hra:/t20000
pf:/t35000
gpay:/t135000
npay:/t100000
Press any key to continue . . .

    */


