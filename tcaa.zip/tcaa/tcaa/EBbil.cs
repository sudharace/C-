﻿using System;
/* example for Eb bill
 */ 

namespace pro
{
    enum ConsumerCatagory
    {
        agriculture, domestic, coomercial
    }


    class EBbil

    {
        public static void Main()
        {

            int cid = 0;
            Console.WriteLine("\n Consumer ID: ");
            int.TryParse(Console.ReadLine(), out cid);

            int pread = 0;
            Console.Write("\nConsume previous Reading:");
            int.TryParse(Console.ReadLine(), out pread);
            int cread = 0;
            Console.Write("\n consumer current reading");
            int.TryParse(Console.ReadLine(), out cread);
            if (cread < pread)
            {

                Console.WriteLine("\nInvalid Reading...");
                return;
            }
            ConsumerCatagory cc = ConsumerCatagory.coomercial;

            Console.Write("\n0.agriculture");
            Console.Write("\n1.domestic");
            Console.Write("\n2.commercial");
            Console.Write("\n[0,1 or 2]");
            int i = 2;
            int.TryParse(Console.ReadLine(), out i);

            if (Enum.IsDefined(typeof(ConsumerCatagory), i) == false)
            {
                Console.WriteLine("Invalid:net reading");
                return;

            }
            int nread = cread - pread;
            if (nread < 0)
            {
                Console.WriteLine("Invalid : Net reading ");
                return;
            }
            int cuu100 = 0, cuu200 = 0, cuu400 = 0, cua400 = 0;
            if (nread > 400)
            {

                cuu100 = 100;
                cuu200 = 200;
                cuu400 = 200;
                cua400 = nread - 400;
            }
            else if (nread > 200)
            {


                cuu100 = 100;
                cuu200 = 100;
                cuu400 = nread - 200;
            }
            else if (nread > 100)
            {
                cuu100 = 100;
                cuu200 = nread - 100;

            }
            else if (nread > 0)
            {
                cuu100 = nread;
            }
            double puau100 = 0, puau200 = 0, puau400 = 0, puaa400 = 0;
            double cuau100 = 0, cuau200 = 0, cuau400 = 0, cuaa400 = 0;
            double mc = 0, taxp = 0, taxa = 0, npay = 0;

            cc = (ConsumerCatagory)i;
            if (cc == ConsumerCatagory.agriculture)
            {
                puau100 = 0.25;
                puau200 = 0.50;
                puau400 = 1.50;
                puaa400 = 2.00;
                mc = 12.50;
                taxp = 2.5;
            }
            if (cc == ConsumerCatagory.domestic)
            {

                puau100 = 0.50;
                puau200 = 1.00;
                puau400 = 3.00;
                puaa400 = 6.00;
                mc = 200.00;
                taxp = 7.5;
            }

            if (cc == ConsumerCatagory.coomercial)
            {


                puau100 = 1.00;
                puau200 = 2.00;
                puau400 = 6.00;
                puaa400 = 10.00;
                mc = 200.00;
                taxp = 7.5;
            }
            cuau100 = puau100 * cuu100;
            cuau200 = puau200 * cuu200;
            cuau400 = puau400 * cuu400;
            cuaa400 = puaa400 * cua400;
            taxa = (taxp / 100) * cuu400;
            npay = cuau100 + cuau200 + cuau400 + cuaa400 + taxa + mc;

            Console.WriteLine("consume net reading:" + nread);
            if (cuau100 > 0)
            {

                Console.WriteLine("per unit amount up to 100:" + puau100);
                Console.WriteLine("consume  unit  up to 100:" + cuu100);
                Console.WriteLine("consume unit amount up to 100:" + cuau100);
            }

            if (cuau200 > 0)
            {

                Console.WriteLine("per unit amount up to 200:" + puau200);
                Console.WriteLine("consume  unit up to 200:" + cuu200);
                Console.WriteLine("consume unit amount up to 200:" + cuau200);
            }
            if (cuau400 > 0)

            {
                Console.WriteLine("per unit amount up to 400:" + puau400);
                Console.WriteLine("consume  unit  up to 400:" + cuu400);
                Console.WriteLine("consume unit amount up to 400:" + cuau400);

            }
            if (cuaa400 > 0)
            {
                Console.WriteLine("per unit amount above 400:" + puaa400);
                Console.WriteLine("consume  unit above 400:" + cua400);
                Console.WriteLine("per unit amount above  400:" + cuaa400);

                Console.WriteLine("tax amount :" + mc);
            }
            Console.WriteLine("meter charge:" + mc);
            Console.WriteLine("netpay:" + npay);



        }


    }
}
/*
 
 Consumer ID:
1001

Consume previous Reading:0

 consumer current reading:50

0.agriculture
1.domestic
2.commercial
[0,1 or 2]
consume net reading:0
meter charge:12.5
netpay:12.5
Press any key to continue . . .

Consumer ID:
1001

Consume previous Reading:0

 consumer current reading150

0.agriculture
1.domestic
2.commercial
[0,1 or 2]
consume net reading:150
per unit amount up to 100:0.25
consume  unit  up to 100:100
consume unit amount up to 100:25
per unit amount up to 200:0.5
consume  unit up to 200:50
consume unit amount up to 200:25
meter charge:12.5
netpay:62.5

Consumer ID:
1001

Consume previous Reading:0

 consumer current reading350

0.agriculture
1.domestic
2.commercial
[0,1 or 2]
consume net reading:350
per unit amount up to 100:0.25
consume  unit  up to 100:100
consume unit amount up to 100:25
per unit amount up to 200:0.5
consume  unit up to 200:100
consume unit amount up to 200:50
per unit amount up to 400:1.5
consume  unit  up to 400:150
consume unit amount up to 400:225
meter charge:12.5
netpay:316.25

 Consumer ID:
1001

Consume previous Reading:0

 consumer current reading550

0.agriculture
1.domestic
2.commercial
[0,1 or 2]
consume net reading:550
per unit amount up to 100:0.25
consume  unit  up to 100:100
consume unit amount up to 100:25
per unit amount up to 200:0.5
consume  unit up to 200:200
consume unit amount up to 200:100
per unit amount up to 400:1.5
consume  unit  up to 400:200
consume unit amount up to 400:300
per unit amount above 400:2
consume  unit above 400:150
per unit amount above  400:300
tax amount :12.5
meter charge:12.5
netpay:742.5

*/




