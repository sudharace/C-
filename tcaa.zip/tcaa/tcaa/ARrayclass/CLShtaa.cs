﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
// EXample for hashtable (a,b,c)

namespace pro.ARrayclass
{
    class CLShtaa
    {
        public static void Main()
        {
            Hashtable HTobj = new Hashtable();
            HTobj["box"] = 11;
            HTobj[22] = "Fox";
        }
    }
}
// for each (var v1 in HTobj.keys)
//Console.WriteLine(HTobj[v1]);