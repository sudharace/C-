﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pro.ARrayclass
{
    class CLSChkUnChkab
    {
        public static void Main()
        {
            int x = int.MinValue;
                int y = int.MinValue;

            Console.WriteLine(x);
            Console.WriteLine(y);

            checked
            {
                //Console.WriteLine(--x);//overflowException
            }
            checked
            {
                //Console.WriteLine(++y);//overflowException

            }
        }
    }
}
