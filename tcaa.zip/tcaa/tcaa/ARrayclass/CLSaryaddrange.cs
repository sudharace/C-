﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
// example for  add range (array) 
namespace pro.ARrayclass
{
    class CLSaryaddrange
    {
        public static void Main()
        { 
        
            ArrayList ALobja = new ArrayList();
            ALobja.Add("Box");//object
            ALobja.Add(11);//object

            ArrayList ALobjb = new ArrayList();
            ALobja.Add(4.2);
            ALobjb.Add(true);
            ALobja.AddRange(ALobjb);
            foreach (var v1 in ALobja)
                Console.WriteLine(v1);

            
        }
    }
}
/*
 Box
11
4.2
True
*/
