﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pro.ARrayclass
{
    class CLSvarac
    {
        public static void Main()
        {
            var er = new { rno = 1001, sname = new { Fname = "ganesh", Lname = "siva" } };
            Console.WriteLine("Roll no.:{0}", er.rno);
            Console.WriteLine("Name:{0}", er.sname);
            Console.WriteLine("First name.:{0}", er.sname.Fname);
            Console.WriteLine("Lsat name.:{0}", er.sname.Lname);

        }
    }
}
/*
 Roll no.:1001
Name:{ Fname = ganesh, Lname = siva }
First name.:ganesh
Lsat name.:siva
*/