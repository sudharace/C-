﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Example for dicitionary object 
// dictionary key can handle from any one data type 
namespace pro.ARrayclass
{
    class CLSDictionary
    {
        public static void Main(string[] args)
        {
           Dictionary<string,string> SDobj = new Dictionary<string, string>();

            SDobj.Add("Box ", "11");
            SDobj.Add("Fox", "22");

            foreach (string strkey in SDobj.Keys)
            {
                Console.WriteLine(strkey);

}
            foreach (String strval in SDobj.Values)
            Console.WriteLine(strval);
            
        }
    }
}
/*
 Box
Fox
11
22
*/