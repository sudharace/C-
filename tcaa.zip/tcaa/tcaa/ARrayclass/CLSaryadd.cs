﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
/* example for add method in arraylist */
namespace pro.ARrayclass
{
    class CLSaryadd
    {
        public static void Main()
        {
            ArrayList ALobj = new ArrayList();

            ALobj.Add("Box");//object array (string)
           
            ALobj.Add(11);//object array (int)
            ALobj.Add(true);//object array (bool)

            foreach (var v1 in ALobj)//this statement called simple

                Console.WriteLine(v1);//without code block statement
        }
    }
}
/*
 Box
11
True
*/