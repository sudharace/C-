﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//example for  get range
namespace pro.ARrayclass
{
    class CLSarygetrange
    {
        public static void Main()
        {
            ArrayList ALobja = new ArrayList();

            ALobja.Add("Box");
            ALobja.Add(11);
            ALobja.Add(4.2);
            ALobja.Add(true);
            ArrayList ALobjb = ALobja.GetRange(2, 2);

            foreach (var v1 in ALobjb)
                Console.WriteLine(v1);


        }
    }
}
/*
 4.2
True
*/
