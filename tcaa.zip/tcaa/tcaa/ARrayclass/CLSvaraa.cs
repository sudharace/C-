﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* tilte :example for 'var' data-type
 */
namespace pro.ARrayclass
{
    class CLSvaraa
    {
        public static void Main()
        {

            var i = 5.9;
            Console.WriteLine("\n{0} : {1}", i, i.GetType());
            i = 9.2f;
            Console.WriteLine("\n{0} : {1}", i, i.GetType());
               i = 4;
            Console.WriteLine("\n{0} : {1}", i, i.GetType());
            //i="fox";
            //cannot implicity converyt typr 'float'to 'int'

            //  var x = 7;//'x' data-type:int
            //x=3.8f;
            //cannot implicity converyt typr 'float'to 'int'
            //  Console.WriteLine("\n{0}:{1}", i, i.GetType());

        }
    }
}
/*
 5.9 : System.Double

9.19999980926514 : System.Double

4 : System.Double
*/