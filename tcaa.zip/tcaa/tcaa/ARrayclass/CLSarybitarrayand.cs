﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
//example for bitarray/and

namespace pro.ARrayclass
{
    class CLSarybitarrayand
    {
        static void Display(BitArray BAobj)
        {
            foreach (bool b in BAobj)
            {
                Console.WriteLine(b ? 1 : 0);
            }
            Console.WriteLine("\n");

        }
        static void Main()
        {
            BitArray BAobjA = new BitArray(6);
            BAobjA[0] = true;
            BAobjA[2] = true;
            BAobjA.Set(5, true);
            Display(BAobjA);


            BitArray BAobjB = new BitArray(6);
            BAobjB[5] = true;
            Display(BAobjB);
            BAobjA.And(BAobjB);
            Display(BAobjA);
        }
    }
}
/*
 1
0
1
0
0
1


0
0
0
0
0
1


0
0
0
0
0
1 
*/